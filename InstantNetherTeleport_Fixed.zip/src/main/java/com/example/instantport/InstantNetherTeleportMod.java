package com.example.instantport;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.UUID;

public class InstantNetherTeleportMod implements ModInitializer {
    public static final String MOD_ID = "instantport";
    private static final HashMap<UUID, Boolean> wasFlying = new HashMap<>();

    @Override
    public void onInitialize() {
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (player.hasVehicle()) continue;
                if (player.isFallFlying()) {
                    wasFlying.put(player.getUuid(), true);
                }
                if (player.isInsidePortal) {
                    RegistryKey<World> targetDim = player.getWorld().getRegistryKey() == World.NETHER ? World.OVERWORLD : World.NETHER;
                    ServerWorld targetWorld = server.getWorld(targetDim);
                    if (targetWorld == null) return;

                    Vec3d pos = player.getPos();
                    float yaw = player.getYaw();
                    float pitch = player.getPitch();
                    Vec3d vel = player.getVelocity();
                    boolean flying = wasFlying.getOrDefault(player.getUuid(), false);

                    player.teleport(targetWorld, pos.getX(), pos.getY(), pos.getZ(), yaw, pitch);
                    player.setVelocity(vel);
                    player.velocityModified = true;
                    if (flying) {
                        player.startFallFlying();
                    }
                    wasFlying.remove(player.getUuid());
                }
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            wasFlying.remove(handler.getPlayer().getUuid());
        });
    }
}